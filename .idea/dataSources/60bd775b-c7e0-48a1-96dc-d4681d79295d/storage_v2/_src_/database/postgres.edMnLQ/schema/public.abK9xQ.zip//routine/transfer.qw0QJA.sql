create procedure transfer(sender integer, receiver integer, amount numeric)
    language plpgsql
as
$$
declare
begin
    update employees
    set salary = salary - amount
    where employee_id = sender;

    update employees
    set salary = salary+amount
    where employee_id = receiver;
    commit ;
end
$$;

alter procedure transfer(integer, integer, numeric) owner to postgres;

