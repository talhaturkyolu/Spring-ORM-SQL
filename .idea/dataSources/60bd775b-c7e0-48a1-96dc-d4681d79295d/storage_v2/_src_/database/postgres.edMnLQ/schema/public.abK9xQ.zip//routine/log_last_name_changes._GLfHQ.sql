create function log_last_name_changes() returns trigger
    language plpgsql
as
$$
begin
        IF NEW.last_name <> OLD.last_name THEN
            INSERT INTO  mentor_audit(MENTOR_ID, LAST_NAME, CHANGED_ON) VALUES
            (OLD.id,OLD.last_name,now());
        end if;

        RETURN new;
    end;
$$;

alter function log_last_name_changes() owner to postgres;

